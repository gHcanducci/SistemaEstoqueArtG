﻿using InfraEstrutura.Data;
using InfraEstrutura.Entidades;
using Repositório.Classes;
using Repositório.Interfaces;
using System;
using System.Linq;
using System.Windows;

namespace SistemaEstoque
{
    public partial class EstoqueWindow : Window
    {
        private readonly IProdutoRepositorio _produtoRepositorio;
        private readonly ProjetoContext _contexto;

        public EstoqueWindow()
        {
            InitializeComponent();

            // Instancia o contexto e o repositório corretamente
            _contexto = new ProjetoContext();
            _produtoRepositorio = new ProdutoRepositorio(_contexto);

            CarregarProdutos();
        }

        private void CarregarProdutos()
        {
            try
            {
                var produtos = _produtoRepositorio.ObterTodos();
                dgEstoque.ItemsSource = produtos;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar o estoque:\n{ex.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Pesquisar(object sender, RoutedEventArgs e)
        {
            try
            {
                string termo = txtBuscarProduto.Text.Trim();

                if (string.IsNullOrEmpty(termo))
                {
                    CarregarProdutos();
                    return;
                }

                var resultados = _produtoRepositorio.ObterPorNome(termo);
                dgEstoque.ItemsSource = resultados;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro na pesquisa:\n{ex.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void NovaEntrada(object sender, RoutedEventArgs e)
        {
            try
            {
                if (dgEstoque.SelectedItem is Produto produtoSelecionado)
                {
                    int qtdEntrada = InputDialog("Informe a quantidade de entrada:");
                    if (qtdEntrada <= 0)
                    {
                        MessageBox.Show("Informe uma quantidade válida.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    // Atualiza a quantidade total do produto
                    produtoSelecionado.Quantidade += qtdEntrada;

                    // Cria registro de entrada
                    var entrada = new EntradaProduto
                    {
                        ProdutoId = produtoSelecionado.Id,
                        Quantidade = qtdEntrada,
                        DataEntrada = DateTime.Now
                    };

                    _contexto.EntradaProduto.Add(entrada);
                    _produtoRepositorio.alterar(produtoSelecionado);

                    MessageBox.Show("Entrada registrada com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                    CarregarProdutos();
                }
                else
                {
                    MessageBox.Show("Selecione um produto para registrar a entrada.", "Atenção", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao registrar entrada:\n{ex.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RegistrarSaida(object sender, RoutedEventArgs e)
        {
            try
            {
                if (dgEstoque.SelectedItem is Produto produtoSelecionado)
                {
                    int qtdSaida = InputDialog("Informe a quantidade de saída:");
                    if (qtdSaida <= 0)
                    {
                        MessageBox.Show("Informe uma quantidade válida.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    if (qtdSaida > produtoSelecionado.Quantidade)
                    {
                        MessageBox.Show("Quantidade de saída maior que o estoque atual!", "Erro", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    // Atualiza a quantidade total
                    produtoSelecionado.Quantidade -= qtdSaida;

                    // Cria registro de saída
                    var saida = new SaidaProduto
                    {
                        ProdutoId = produtoSelecionado.Id,
                        Quantidade = qtdSaida,
                        DataSaida = DateTime.Now
                    };

                    _contexto.SaidaProduto.Add(saida);
                    _produtoRepositorio.alterar(produtoSelecionado);

                    MessageBox.Show("Saída registrada com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                    CarregarProdutos();
                }
                else
                {
                    MessageBox.Show("Selecione um produto para registrar a saída.", "Atenção", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao registrar saída:\n{ex.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private int InputDialog(string mensagem)
        {
            var inputBox = Microsoft.VisualBasic.Interaction.InputBox(mensagem, "Controle de Estoque", "0");
            return int.TryParse(inputBox, out int valor) ? valor : 0;
        }

        private void CadastrarProduto(object sender, RoutedEventArgs e)
        {
            try
            {
                string nome = Microsoft.VisualBasic.Interaction.InputBox("Nome do produto:", "Cadastrar Produto", "");
                if (string.IsNullOrWhiteSpace(nome))
                {
                    MessageBox.Show("Informe um nome válido para o produto.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                string valorStr = Microsoft.VisualBasic.Interaction.InputBox("Valor do produto:", "Cadastrar Produto", "0");
                if (!decimal.TryParse(valorStr, out decimal valor) || valor < 0)
                {
                    MessageBox.Show("Valor inválido.", "Erro", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                string qtdStr = Microsoft.VisualBasic.Interaction.InputBox("Quantidade inicial:", "Cadastrar Produto", "0");
                if (!int.TryParse(qtdStr, out int quantidade) || quantidade < 0)
                {
                    MessageBox.Show("Quantidade inválida.", "Erro", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Cria novo produto
                var novoProduto = new Produto
                {
                    Nome = nome,
                    Valor = valor,
                    Quantidade = quantidade,
                    Reposicao = 0 // 0 = não precisa repor
                };

                _produtoRepositorio.adicionar(novoProduto);

                MessageBox.Show("Produto cadastrado com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                CarregarProdutos();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao cadastrar produto:\n{ex.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}